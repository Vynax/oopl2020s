var MyBox2D = Framework.Class(Framework.Level, {
		load : function () {
			
		},
		
		initialize : function () {
			
		},

		update : function () {
			
		},

		draw : function (parentCtx) {
			
		},
		
	});
